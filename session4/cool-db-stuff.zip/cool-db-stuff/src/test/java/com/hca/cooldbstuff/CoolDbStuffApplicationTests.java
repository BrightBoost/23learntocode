package com.hca.cooldbstuff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoolDbStuffApplicationTests {

	@Test
	void contextLoads() {
	}

}
