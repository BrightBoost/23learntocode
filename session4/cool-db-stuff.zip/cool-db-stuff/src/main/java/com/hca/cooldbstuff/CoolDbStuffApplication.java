package com.hca.cooldbstuff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoolDbStuffApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoolDbStuffApplication.class, args);
	}

}
